package Chats;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ChatServerTest {

    @Test
    public void testInitialState() {
        // Test initialization of the ChatServer
        // You can check if certain initial conditions are met
        // For example, if the memberWriters map is empty initially
        ChatServer chatServer = new ChatServer();
        assertTrue(chatServer.getMemberWriters().isEmpty());
    }

    @Test
    public void testMemberJoin() {
        // Test the join functionality of the ChatServer
        ChatServer chatServer = new ChatServer();
        chatServer.memberJoin("TestMember", "localhost", 12345);
        assertTrue(chatServer.getMemberWriters().containsKey("TestMember"));
    }

    @Test
    public void testMemberQuit() {
        // Test the quit functionality of the ChatServer
        ChatServer chatServer = new ChatServer();
        chatServer.memberJoin("TestMember", "localhost", 12345);
        chatServer.memberQuit("TestMember");
        assertFalse(chatServer.getMemberWriters().containsKey("TestMember"));
    }

    @Test
    public void testCoordinatorAssignment() {
        // Test if the coordinator is assigned properly when joining
        ChatServer chatServer = new ChatServer();
        chatServer.memberJoin("Coordinator", "localhost", 12345);
        assertEquals("Coordinator", chatServer.getCoordinatorID());
    }

    @Test
    public void testCoordinatorChangeOnQuit() {
        // Test if coordinator changes when the current coordinator quits
        ChatServer chatServer = new ChatServer();
        chatServer.memberJoin("Coordinator", "localhost", 12345);
        chatServer.memberJoin("Member1", "localhost", 12346);
        chatServer.memberJoin("Member2", "localhost", 12347);
        chatServer.memberQuit("Coordinator");
        assertEquals("Member1", chatServer.getCoordinatorID());
    }

    @Test
    public void testCoordinatorStaysOnNonCoordinatorQuit() {
        // Test if coordinator remains the same when a non-coordinator member quits
        ChatServer chatServer = new ChatServer();
        chatServer.memberJoin("Coordinator", "localhost", 12345);
        chatServer.memberJoin("Member1", "localhost", 12346);
        chatServer.memberJoin("Member2", "localhost", 12347);
        chatServer.memberQuit("Member1");
        assertEquals("Coordinator", chatServer.getCoordinatorID());
    }

    // Add more test methods as needed to cover different functionalities
}
