package Chats;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class ChatClientGUI extends JFrame {
    private Socket socket;
    private PrintWriter writer;
    private JTextArea chatArea;
    private JTextField messageField;
    private String memberName;

    public ChatClientGUI(String memberName, String serverAddress, int serverPort) {
        this.memberName = memberName;
        setTitle("Chat Client - " + memberName);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLayout(new BorderLayout());

        chatArea = new JTextArea();
        chatArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(chatArea);
        add(scrollPane, BorderLayout.CENTER);

        messageField = new JTextField();
        JButton sendButton = new JButton("Send");
        JButton quitButton = new JButton("Quit");
        JButton getStateButton = new JButton("Get State");
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.add(messageField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        inputPanel.add(quitButton, BorderLayout.WEST);
        inputPanel.add(getStateButton, BorderLayout.SOUTH);
        add(inputPanel, BorderLayout.SOUTH);

        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sendMessage();
            }
        });

        quitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                quitChat();
            }
        });

        getStateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                requestState();
            }
        });

        try {
            socket = new Socket(serverAddress, serverPort);
            writer = new PrintWriter(socket.getOutputStream(), true);
            writer.println(memberName + "," + InetAddress.getLocalHost().getHostAddress() + "," + socket.getLocalPort());
            String welcomeMessage = new BufferedReader(new InputStreamReader(socket.getInputStream())).readLine();
            chatArea.append(welcomeMessage + "\n");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error connecting to server: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        Thread receiveThread = new Thread(() -> {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String message;
                while ((message = reader.readLine()) != null) {
                    chatArea.append(message + "\n");
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
        receiveThread.start();
    }

    private void sendMessage() {
        String message = messageField.getText();
        if (!message.isEmpty()) {
            writer.println(message);
            messageField.setText("");
        }
    }

    private void quitChat() {
        writer.println("quit");
        try {
            socket.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        dispose();
    }

    private void requestState() {
        writer.println("getState");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            String memberName = JOptionPane.showInputDialog(null, "Enter your member name:");
            String serverAddress = JOptionPane.showInputDialog(null, "Enter server IP address:");
            int serverPort = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter server port:"));
            new ChatClientGUI(memberName, serverAddress, serverPort).setVisible(true);
        });
    }
}
