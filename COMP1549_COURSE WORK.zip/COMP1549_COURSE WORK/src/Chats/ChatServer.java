package Chats;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

public class ChatServer {

    private static final String PRIVATE_MESSAGE_PREFIX = "#";
    private static final int STATE_CHECK_INTERVAL = 20000; // 20 seconds

    public static void main(String[] args) {
        System.out.println("The server is running");
        Map<String, PrintWriter> memberWriters = new HashMap<>();
        List<String> memberIDs = new ArrayList<>();
        AtomicReference<String> coordinatorID = new AtomicReference<>(null);

        try {
            ServerSocket serverSocket = new ServerSocket(12345); // Change port as needed
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress().getHostName());

                // Handle client connection here
                PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true);

                // Get member details from client
                BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String[] memberDetails = reader.readLine().split(","); // Read member details from client
                String memberID = memberDetails[0]; // Member ID
                String memberIPAddress = memberDetails[1]; // Member IP Address
                int memberPort = Integer.parseInt(memberDetails[2]); // Member Port
                memberWriters.put(memberID, writer);
                memberIDs.add(memberID);

                // Notify all clients about new member
                for (PrintWriter w : memberWriters.values()) {
                    w.println(memberID + " has joined");
                }

                // Print member ID
                System.out.println("Member ID: " + memberID);

                // If first member, assign as coordinator
                if (coordinatorID.get() == null) {
                    coordinatorID.set(memberID);
                    writer.println("You are the coordinator");
                } else {
                    writer.println("You are a member");
                    writer.println("The current coordinator is: " + coordinatorID.get());
                }

                // Start a new thread to handle messages from this client
                Thread handler = new Thread(new ClientHandler(clientSocket, memberID, memberIPAddress, memberPort, memberWriters, memberIDs, coordinatorID));
                handler.start();

                // Start state checking thread if it's the first member
                if (coordinatorID.get().equals(memberID)) {
                    new Thread(() -> {
                        while (true) {
                            try {
                                Thread.sleep(STATE_CHECK_INTERVAL);
                                checkState(memberWriters, memberIDs, coordinatorID);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }).start();
                }
            }
        } catch (IOException ex) {
            System.err.println("Error starting server: " + ex.getMessage());
        }
    }

    // Method to check and update state (coordinator)
    private static void checkState(Map<String, PrintWriter> memberWriters, List<String> memberIDs, AtomicReference<String> coordinatorID) {
        // If coordinator quits, assign new coordinator
        if (!memberIDs.isEmpty() && !coordinatorID.get().equals(memberIDs.get(0))) {
            coordinatorID.set(memberIDs.get(0));
            for (PrintWriter w : memberWriters.values()) {
                w.println("New coordinator is: " + coordinatorID.get());
            }
        }
    }

    static class ClientHandler implements Runnable {
        private Socket clientSocket;
        private String memberID;
        private String memberIPAddress;
        private int memberPort;
        private Map<String, PrintWriter> memberWriters;
        private List<String> memberIDs;
        private AtomicReference<String> coordinatorID;

        public ClientHandler(Socket clientSocket, String memberID, String memberIPAddress, int memberPort, Map<String, PrintWriter> memberWriters, List<String> memberIDs, AtomicReference<String> coordinatorID) {
            this.clientSocket = clientSocket;
            this.memberID = memberID;
            this.memberIPAddress = memberIPAddress;
            this.memberPort = memberPort;
            this.memberWriters = memberWriters;
            this.memberIDs = memberIDs;
            this.coordinatorID = coordinatorID;
        }

        @Override
        public void run() {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String message;
                while ((message = reader.readLine()) != null) {
                    if (message.equals("quit")) {
                        // Remove the member and inform others
                        memberWriters.remove(memberID);
                        memberIDs.remove(memberID);
                        for (PrintWriter w : memberWriters.values()) {
                            w.println(memberID + " has left the chat");
                        }
                        break; // Exit the loop
                    }
                    if (message.equals("getState")) {
                        // Send state (list of members and coordinator) to the client
                        StringBuilder stateMsg = new StringBuilder("Current state:\n");
                        stateMsg.append("Coordinator: ").append(coordinatorID.get()).append("\n");
                        stateMsg.append("Members:\n");
                        for (String member : memberIDs) {
                            stateMsg.append(member).append("\n");
                        }
                        memberWriters.get(memberID).println(stateMsg.toString());
                    }
                    if (message.startsWith(PRIVATE_MESSAGE_PREFIX)) {
                        // Handle private message
                        int recipientIndex = message.indexOf(":");
                        if (recipientIndex != -1) {
                            String recipient = message.substring(1, recipientIndex);
                            String privateMessage = message.substring(recipientIndex + 1);
                            PrintWriter recipientWriter = memberWriters.get(recipient);
                            if (recipientWriter != null) {
                                recipientWriter.println("[Private message from " + memberID + "]: " + privateMessage);
                            }
                        } else {
                            memberWriters.get(memberID).println("Invalid private message format. Please use: #recipientName:message");
                        }
                    } else {
                        // Broadcast message to all clients
                        for (PrintWriter w : memberWriters.values()) {
                            w.println("[" + memberID + "]: " + message);
                        }
                    }
                }
            } catch (IOException ex) {
                // Handle client disconnect gracefully
                System.err.println("Client disconnected: " + ex.getMessage());
            } finally {
                // Ensure resources are cleaned up
                try {
                    clientSocket.close();
                } catch (IOException ex) {
                    System.err.println("Error closing client socket: " + ex.getMessage());
                }
                // Remove the member and inform others
                memberWriters.remove(memberID);
                memberIDs.remove(memberID);
                for (PrintWriter w : memberWriters.values()) {
                    w.println(memberID + " has left the chat");
                }
            }
        }
    }
}
